# saber-bug-mvp

1. `yarn install`
2. `yarn saber`

Expected: The server starts and `/posts/hello.html` is created.
Observed: Saber hangs and will keep running after `^C`.

Note that `yarn saber build` works as expected.
